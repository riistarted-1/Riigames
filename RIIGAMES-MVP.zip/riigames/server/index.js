import express from 'express';
import cors from 'cors';
import { createServer } from 'node:http';
import { Server } from 'socket.io';
import { randomInt } from 'node:crypto';

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(',') ?? '*' }));
app.get('/health', (_req, res) => res.json({ ok: true, app: 'RIIGAMES' }));
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: process.env.CLIENT_ORIGIN?.split(',') ?? '*', methods: ['GET','POST'] } });
const PORT = process.env.PORT || 3001;
const rooms = new Map();
const WORDS = ['APPLE','MOON','ROBOT','RIVER','PIRATE','CROWN','LASER','GHOST','PIZZA','ORBIT','CASTLE','BOTTLE','JUNGLE','MIRROR','DRAGON','CLOUD','BRIDGE','SHADOW','TIGER','GUITAR','COMET','OCEAN','TRAIN','MOUSE','DIAMOND','WITCH','PILOT','FOREST','ROCKET','SILVER','BANANA','KNIGHT','CHOCOLATE','DESERT','EAGLE','SCHOOL','THUNDER','CANDLE','PLANET','BUTTON','SPIDER','HONEY','CAMERA','WHALE','FIRE','SNOW','KING','QUEEN','BATTERY','PENCIL','BRAIN','PUMPKIN','JACKET','HEART','CIRCUS','SOLDIER','ISLAND','CLOCK','SNAKE','WIZARD'];
const code = () => { let s=''; for(let i=0;i<5;i++) s += 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[randomInt(0,32)]; return s; };
function makeGame(){
  const words=[...WORDS].sort(()=>Math.random()-.5).slice(0,25);
  const keys=[...Array(9).fill('red'),...Array(8).fill('blue'),'assassin',...Array(7).fill('neutral')].sort(()=>Math.random()-.5);
  return {words:words.map((word,i)=>({word,team:keys[i],revealed:false})),turn:'red', redLeft:9,blueLeft:8, clue:null, guessesLeft:0, winner:null, log:[]};
}
function publicRoom(room){ return {code:room.code,hostId:room.hostId,players:[...room.players.values()].map(p=>({id:p.id,name:p.name,team:p.team})),game:room.game,started:room.started}; }
function sendRoom(room){io.to(room.code).emit('room:update',publicRoom(room));}
function error(socket,message){socket.emit('app:error',message);}
io.on('connection',socket=>{
 socket.on('room:create',({name})=>{
  const clean=String(name||'Player').trim().slice(0,18)||'Player'; let id; do{id=code()}while(rooms.has(id));
  const room={code:id,hostId:socket.id,players:new Map(),started:false,game:null}; room.players.set(socket.id,{id:socket.id,name:clean,team:'red'}); rooms.set(id,room); socket.join(id); socket.data.room=id; socket.emit('room:joined',publicRoom(room)); sendRoom(room);
 });
 socket.on('room:join',({code:raw,name})=>{
  const id=String(raw||'').toUpperCase().trim(); const room=rooms.get(id); if(!room)return error(socket,'Room not found. Check the code.'); if(room.started)return error(socket,'That game has already started.');
  const clean=String(name||'Player').trim().slice(0,18)||'Player'; room.players.set(socket.id,{id:socket.id,name:clean,team:room.players.size%2?'blue':'red'}); socket.join(id);socket.data.room=id;socket.emit('room:joined',publicRoom(room));sendRoom(room);
 });
 socket.on('game:start',()=>{const room=rooms.get(socket.data.room);if(!room)return;if(room.hostId!==socket.id)return error(socket,'Only the room host can start.');if(room.players.size<2)return error(socket,'Invite at least one other player first.');room.started=true;room.game=makeGame();sendRoom(room);});
 socket.on('game:clue',({word,count})=>{const room=rooms.get(socket.data.room);if(!room?.game)return;const player=room.players.get(socket.id);const g=room.game;if(!player||player.team!==g.turn||g.clue)return;const clean=String(word||'').trim().toUpperCase().replace(/[^A-Z]/g,'').slice(0,20);const n=Math.max(1,Math.min(9,Number(count)||1));if(!clean)return;g.clue={word:clean,count:n,by:player.name};g.guessesLeft=n+1;g.log.unshift(`${player.name} gave clue: ${clean} (${n})`);sendRoom(room);});
 socket.on('game:guess',({index})=>{const room=rooms.get(socket.data.room);if(!room?.game)return;const player=room.players.get(socket.id);const g=room.game;if(!player||player.team!==g.turn||!g.clue||g.winner)return;const card=g.words[Number(index)];if(!card||card.revealed)return;card.revealed=true;g.guessesLeft--;g.log.unshift(`${player.name} guessed ${card.word}.`);if(card.team==='assassin'){g.winner=g.turn==='red'?'blue':'red';g.log.unshift(`Assassin found. ${g.winner.toUpperCase()} wins!`);}else if(card.team==='red'){g.redLeft--;}else if(card.team==='blue'){g.blueLeft--;}
 if(g.redLeft===0)g.winner='red';if(g.blueLeft===0)g.winner='blue';if(!g.winner&&(card.team!==g.turn||g.guessesLeft<=0)){g.turn=g.turn==='red'?'blue':'red';g.clue=null;g.guessesLeft=0;}sendRoom(room);});
 socket.on('room:leave',()=>leave(socket));
 socket.on('disconnect',()=>leave(socket));
});
function leave(socket){const id=socket.data.room;const room=rooms.get(id);if(!room)return;room.players.delete(socket.id);socket.leave(id);if(!room.players.size){rooms.delete(id);return;}if(room.hostId===socket.id)room.hostId=room.players.keys().next().value;sendRoom(room);socket.data.room=null;}
httpServer.listen(PORT,()=>console.log(`RIIGAMES server listening on ${PORT}`));
