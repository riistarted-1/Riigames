# RIIGAMES MVP
A mobile-first multiplayer Codenames-inspired word game using React, Vite, Express and Socket.IO.

## Requirements
Node.js 20+ and npm.

## Run locally
From this folder:
```bash
npm install
npm --prefix server install
npm --prefix client install
npm run dev
```
Open the Vite URL printed (usually http://localhost:5173). Keep the server terminal running too. For multiplayer testing on separate devices, deploy the server and client or use a secure tunnel; localhost on one phone is not reachable from a friend's phone.

## Deploy
### Backend (Render or Railway)
Deploy the `server` directory as a Node service. Build command: `npm install`; start command: `npm start`. Set `CLIENT_ORIGIN` to your deployed frontend URL (comma-separated origins allowed). The service listens on `PORT`.

### Frontend (Vercel or Netlify)
Deploy the `client` directory as a Vite app. Build command `npm run build`, output directory `dist`. Add environment variable `VITE_SERVER_URL` with the backend's HTTPS URL, then redeploy.

## MVP notes
- Rooms are held in server memory, so they disappear when the backend restarts and won't scale across multiple server instances.
- No accounts or persistent player data.
- This is an original Codenames-inspired word game, not affiliated with the Codenames trademark owner.
- Add Redis, rate limiting, input validation, reconnect handling, and authoritative cluegiver roles before public launch.
